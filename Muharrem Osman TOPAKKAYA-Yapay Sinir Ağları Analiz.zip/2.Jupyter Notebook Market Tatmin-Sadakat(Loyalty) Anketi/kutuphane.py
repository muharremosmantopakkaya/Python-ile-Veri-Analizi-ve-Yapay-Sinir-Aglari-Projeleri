

import seaborn as sns
# Stilleri Seaborn olarak ayarlayın
sns.set()
# Sklearn ile k-means kümeleme yapabilmemiz için KMeans modülünü içe aktarın
from sklearn.cluster import KMeans
